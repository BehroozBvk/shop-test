@extends('layouts.dashboard.master.master')
@section('content')
<div class="row">
    <div class="col-xl-6 col-lg-6 col-xs-12">
        <div class="card">
            <div class="card-body">
                <div class="card-block">
                    <div class="media">
                        <div class="media-body text-xs-left">
                            <h3 class="pink count">{{$users_count}}</h3>
                            <span>Users</span>
                        </div>
                        <div class="media-right media-middle">
                            <i class="icon-group pink font-large-2 float-xs-right"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-xl-6 col-lg-6 col-xs-12">
        <div class="card">
            <div class="card-body">
                <div class="card-block">
                    <div class="media">
                        <div class="media-body text-xs-left">
                            <h3 class="cyan count">{{$products_count}}</h3>
                            <span>Products</span>
                        </div>
                        <div class="media-right media-middle">
                            <i class="icon-cubes cyan font-large-2 float-xs-right"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Area Chart -->
<div class="row">
    <div class="col-xs-12">
        <div class="card">
            <div class="card-header">
                <h4 class="card-title"> Latest products</h4>
                <a class="heading-elements-toggle"><i class="icon-ellipsis font-medium-3"></i></a>
                <div class="heading-elements">
                    <ul class="list-inline mb-0">
                        {{--<li><a data-action="collapse"><i class="icon-minus4"></i></a></li>--}}
                        <li><a data-action="reload"><i class="icon-reload"></i></a></li>
                        <li><a data-action="expand"><i class="icon-expand2"></i></a></li>
                        <li><a data-action="close"><i class="icon-cross2"></i></a></li>
                    </ul>
                </div>
            </div>
            <div class="card-body collapse in">
                <div class="table-responsive">
                    <table class="table table-bordered table-striped">
                        <thead>
                        <tr>
                            <th>Image</th>
                            <th>Product Name</th>
                            <th>Price</th>
                            <th>Tags</th>
                            <th>Date</th>
                        </tr>
                        </thead>
                        <tbody>
                        @foreach($products as $product)
                            <tr>
                                <td><a href="{{route('products.show',str_slug($product->name, '-'))}}"><span class="avatar avatar-lg box-shadow-1"><img class="img-responsive" src="{{$product->image == NULL ? asset('images/no-image.png'):asset('images/products').'/'.$product->image }}"></span></a></td>
                                <td>{{$product->name}}</td>
                                <td>${{$product->price}}</td>
                                <td>
                                    @foreach($product->tag as $tag)
                                        <div class="tag tag-pill tag-primary">{{$tag}}</div>
                                    @endforeach
                                </td>
                                <td>{{$product->created_at}}</td>
                            </tr>
                        @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection