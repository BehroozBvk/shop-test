@extends('layouts.dashboard.master.master')
@section('style')
    <link rel="stylesheet" href="{{asset('css/jquery-ui.css')}}">
    <link rel="stylesheet" href="{{asset('css/sweetalert2.min.css')}}">
@endsection
@section('script')
    <script src="{{asset('js/jquery-ui.min.js')}}"></script>
    <script src="{{asset('js/sweetalert2.min.js')}}"></script>

    <script type="text/javascript">
        $('.typeahead').autocomplete({
            source:'{{route('products.autocomplete')}}',
            minlength:3,
            maxheight:'100px',
            autoFocus:true,
            select:function(e,ui)
            {
                var slug = function(str) {
                    var $slug = '';
                    var trimmed = $.trim(str);
                    $slug = trimmed.replace(/[^a-z0-9-]/gi, '-').
                    replace(/-+/g, '-').
                    replace(/^-|-$/g, '');
                    return $slug.toLowerCase();
                };
                window.location.href = '{{url('/admin/dashboard/products')}}/'+slug(ui.item.value);
            }
        }).data( "ui-autocomplete" )._renderItem = function( ul, item ) {
            return $( "<li></li>" )
                .data( "item.autocomplete", item )
                .append( "<span class='avatar avatar-md'>" + "<img src='{{asset('images/products')}}/" +((item.image == null) ? 'no-image.png' : item.image) + "' /> " + item.value+ "</span>" )
                .appendTo( ul )
        };
    </script>
@endsection
@section('content')
    <div class="row">
        <div class="col-xs-12">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title">Products List</h4>
                    <a class="heading-elements-toggle"><i class="icon-ellipsis font-medium-3"></i></a>
                    <div class="heading-elements">
                        <ul class="list-inline mb-0">
                            <li><a data-action="collapse"><i class="icon-minus4"></i></a></li>
                            <li><a data-action="reload"><i class="icon-reload"></i></a></li>
                            <li><a data-action="expand"><i class="icon-expand2"></i></a></li>
                            <li><a data-action="close"><i class="icon-cross2"></i></a></li>
                        </ul>
                    </div>
                </div>

                <div class="card-body collapse in">
                    <div class="card-block card-dashboard bs-example">
                        @role('admin')
                            <div class="col-lg-10 col-md-10 col-xs-12">
                                <input class="typeahead form-control" name="query" type="text" placeholder="Filter search by product tag ">
                            </div>
                        @endrole

                        <div class="col-lg-2 col-md-2 col-xs-12">
                            <a href="{{route('products.create')}}" class="btn btn-success btn-block"><i class="icon-circle-plus"></i> New</a>
                        </div>
                    </div>
                    <div class="table-responsive">
                        <table class="table table-bordered table-striped">
                            <thead>
                            <tr>
                                <th>#</th>
                                <th>Image</th>
                                <th>Product Name</th>
                                <th>Price</th>
                                <th>Tags</th>
                                <th>Date</th>
                            </tr>
                            </thead>
                            <tbody>
                                @foreach($products as $product)
                                    <tr>
                                        <th scope="row">{{$i++}}</th>
                                        <td><a href="{{route('products.show',str_slug($product->name, '-'))}}"><span class="avatar avatar-lg box-shadow-1"><img class="img-responsive" src="{{$product->image == NULL ? asset('images/no-image.png'):asset('images/products').'/'.$product->image }}"></span></a></td>
                                        <td>{{$product->name}}</td>
                                        <td>${{$product->price}}</td>
                                        <td>
                                            @foreach($product->tag as $tag)
                                                <div class="tag tag-pill tag-primary">{{$tag}}</div>
                                            @endforeach
                                        </td>
                                        <td>{{$product->created_at}}</td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                    <div class="card-block">
                        {{ $products->links() }}
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection