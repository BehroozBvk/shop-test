@extends('layouts.dashboard.master.master')
@section('style')
    <link rel="stylesheet" href="{{asset('css/sweetalert2.min.css')}}">
@endsection
@section('script')
    <script src="{{asset('js/sweetalert2.min.js')}}"></script>
    <script type="text/javascript">
        $(document).ready(function() {
            @if (session('success'))
            swal({
                title: 'success',
                text: '{{ session('success') }}',
                type: 'success',
                confirmButtonText: 'ok'
            });

            @endif
        });
    </script>
@endsection
@section('content')
    <div class="card">
        <div class="card-header">
            <h4 class="card-title" id="basic-layout-form">Product New</h4>
            <a class="heading-elements-toggle"><i class="icon-ellipsis col-lg-3 font-medium-4"></i></a>
            <div class="heading-elements">
                <ul class="list-inline mb-0">
                    <li><a data-action="expand"><i class="icon-expand2"></i></a></li>
                    <li><a data-action="close"><i class="icon-cross2"></i></a></li>
                </ul>
            </div>
        </div>
        <div class="card-block">
            <div class="card-body collapse in">
                @if ($errors->any())
                    <div class="alert alert-danger">
                        <ul>
                            @foreach ($errors->all() as $error)
                                <li>{{ $error }}</li>
                            @endforeach
                        </ul>
                    </div>
                @endif
                <form class="form" action="{{route('products.store')}}" method="post" enctype="multipart/form-data">
                    {{csrf_field()}}
                    <div class="form-body">
                        <h4 class="form-section"><i class="icon-cubes"></i> Product Info</h4>

                        <div class="row">
                            <div class="col-lg-3 col-md-4">
                                <div class="form-group">
                                    <label for="first_name">Name</label>
                                    <div class="input-group">
                                        <span class="input-group-addon"><i class="icon-pencil3"></i></span>
                                        <input type="text" id="first_name" class="form-control {{$errors->has('name') ? 'border-danger' : ''}}" placeholder="Product Name"
                                           name="name" value="{{ old('name') }}">
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-4">
                                <div class="form-group">
                                    <label for="price">Price</label>
                                    <div class="input-group">
                                        <span class="input-group-addon">$</span>
                                        <input type="text" class="form-control {{$errors->has('price') ? 'border-danger' : ''}}" placeholder="price" aria-label="Amount (to the nearest dollar)" name="price" value="{{old('price')}}">
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-4">
                                <div class="form-group">
                                    <label for="price">Tags</label>
                                    <div class="input-group">
                                        <span class="input-group-addon"><i class="icon-tags"></i></span>
                                        <input type="text" id="tag" class="form-control {{$errors->has('tag') ? 'border-danger' : ''}}" placeholder="( , ) add Multi tag with seprator comma"
                                               name="tag" value="{{ old('tag') }}">
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-4">
                                <div class="form-group">
                                    <label>Select Image</label>
                                    <label id="image" class="file center-block">
                                        <input type="file" id="file" name="image">
                                        <span class="file-custom"></span>
                                    </label>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label for="Content">Content</label>
                                    <div class="position-relative has-icon-left">
                                        <textarea id="Content" rows="5" class="form-control {{$errors->has('content') ? 'border-danger' : ''}}" name="content" placeholder="Content">{{old('content')}}</textarea>
                                        <div class="form-control-position">
                                            <i class="icon-file2"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>

                    </div>

                    <div class="form-actions">
                        <button type="submit" class="btn btn-success mr-1">
                            <i class="icon-check2"></i> save
                        </button>
                        <a href="{{route('products')}}" class="btn btn-danger">
                            <i class="icon-ios-undo"></i> Back
                        </a>
                    </div>
                </form>
            </div>
        </div>
    </div>
    </div>
@endsection