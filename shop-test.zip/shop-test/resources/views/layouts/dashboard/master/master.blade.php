@include('layouts.dashboard.master.header')
@include('layouts.dashboard.master.sidebar')
<div class="app-content content container-fluid">
    <div class="content-wrapper">
        <div class="content-header row">
        </div>
        <div class="content-body" id="bvk"><!-- stats -->
            @yield('content')
        </div>
    </div>
</div>
@include('layouts.dashboard.master.footer')
