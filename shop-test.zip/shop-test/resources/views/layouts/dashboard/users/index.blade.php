@extends('layouts.dashboard.master.master')
@section('style')
    <link rel="stylesheet" href="{{asset('css/sweetalert2.min.css')}}">
@endsection
@section('script')
    <script src="{{asset('js/axios.min.js')}}"></script>
    <script src="{{asset('js/sweetalert2.min.js')}}"></script>
    <script src="{{asset('js/persian-date.min.js')}}"></script>
    <script>
        $(document).ready(function(){
            $(".edit_user").click(function(e){
                e.preventDefault();
                axios.post('{{route('users.edit')}}',{
                    id:$(this).attr('data-id')
                })
                    .then(function (response) {
                        $(".edit_id").val(response.data.id);
                        $(".user-name").val(response.data.name);
                        $(".user-email").val(response.data.email);
                    })
                    .catch(function (error) {
                        console.log(error);
                    });
            });

            $(".assign_role_user").click(function(e){
                e.preventDefault();
                var user = $(this).attr('data-id');
                $('.user_id').attr('value',user);
            });
        });
        @if (session('success'))
            swal({
                title: 'Update',
                text: '{{ session('success') }}',
                type: 'success',
                confirmButtonText: 'ok'
            });
        @endif
    </script>
@endsection
@section('content')
    <div class="row">
        <div class="col-xs-12">
            <div class="card">
                <div class="card-header">

                    <h4 class="card-title">Users List</h4>
                    <a class="heading-elements-toggle"><i class="icon-ellipsis font-medium-3"></i></a>
                    <div class="heading-elements">
                        <ul class="list-inline mb-0">
                            <li><a data-action="collapse"><i class="icon-minus4"></i></a></li>
                            <li><a data-action="reload"><i class="icon-reload"></i></a></li>
                            <li><a data-action="expand"><i class="icon-expand2"></i></a></li>
                            <li><a data-action="close"><i class="icon-cross2"></i></a></li>
                        </ul>
                    </div>
                    @if ($errors->any())
                        <div class="m-1">
                            <div class="alert alert-danger alert-dismissible fade in mb-2" role="alert">
                                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                    <span aria-hidden="true">×</span>
                                </button>
                                <ul>
                                    @foreach ($errors->all() as $error)
                                        <li>{{ $error }}</li>
                                    @endforeach
                                </ul>
                            </div>
                        </div>
                    @endif
                </div>

                <div class="card-body collapse in">
                    <div class="card-block card-dashboard bs-example">
                        <!-- Modal Edit -->
                        <div class="modal fade text-xs-left" id="editUser" tabindex="-1" role="dialog" aria-labelledby="myModalLabel33" aria-hidden="true">
                            <div class="modal-dialog" role="document">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                            <span aria-hidden="true">&times;</span>
                                        </button>
                                        <label class="modal-title text-bold-600" id="myModalLabel33">Edit User</label>
                                    </div>
                                    <div class="card-block">
                                        <form class="form-horizontal form-simple" method="POST" action="{{ route('users.update') }}" autocomplete="none">
                                            {{ csrf_field() }}
                                            <input name="edit_id" type="hidden" class="edit_id">
                                            <fieldset class="form-group position-relative has-icon-left mb-1 {{ $errors->has('name') ? ' has-error' : '' }}">
                                                <input type="text" class="form-control form-control-lg input-lg user-name" name="name" value="{{ old('name') }}" required autofocus id="user-name" placeholder="First Name">
                                                <div class="form-control-position">
                                                    <i class="icon-head"></i>
                                                </div>
                                            </fieldset>
                                            <fieldset class="form-group {{ $errors->has('email') ? ' has-error' : '' }} position-relative has-icon-left mb-1">
                                                <input type="email" class="form-control form-control-lg input-lg user-email" name="email" value="{{ old('email') }}" id="user-email" placeholder="Email" required>
                                                <div class="form-control-position">
                                                    <i class="icon-mail6"></i>
                                                </div>
                                            </fieldset>
                                            <fieldset class="form-group position-relative has-icon-left {{ $errors->has('password') ? ' has-error' : '' }}">
                                                <input type="password" class="form-control form-control-lg input-lg" name="password" id="user-password" placeholder="Password" >
                                                <div class="form-control-position">
                                                    <i class="icon-key3"></i>
                                                </div>
                                            </fieldset>
                                            <fieldset class="form-group position-relative has-icon-left {{ $errors->has('password') ? ' has-error' : '' }}">
                                                <input type="password" class="form-control form-control-lg input-lg" name="password_confirmation" id="password-confirm" placeholder="Confirm Password" >
                                                <div class="form-control-position">
                                                    <i class="icon-key3"></i>
                                                </div>
                                            </fieldset>
                                            <button type="submit" class="btn btn-blue btn-lg btn-block"><i class="icon-save"></i> Update</button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- Modal Assign Role -->
                        <div class="modal fade text-xs-left" id="assignRole" tabindex="-1" role="dialog" aria-labelledby="myModalLabel33" aria-hidden="true">
                            <div class="modal-dialog" role="document">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                            <span aria-hidden="true">&times;</span>
                                        </button>
                                        <label class="modal-title text-bold-600" id="myModalLabel33">Assign Role To User</label>
                                    </div>
                                    <div class="card-block">
                                        <form action="{{route('users.assign')}}" method="post">
                                            {{csrf_field()}}
                                            <div class="modal-body">
                                                <label>Role : </label>
                                                <div class="form-group">
                                                    <input type="hidden" value="" class="user_id" name="user_id">
                                                    <select id="role" name="role" class="form-control {{$errors->has('role') ? 'border-danger' : ''}}">
                                                        <option value="" selected disabled>Select</option>
                                                        @foreach($roles as $role)
                                                            <option value="{{$role->id}}">{{$role->name}}</option>
                                                        @endforeach
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="modal-footer">
                                                <input type="reset" class="btn btn-outline-secondary btn-lg" data-dismiss="modal" value="Cancel">
                                                <button type="submit" class="btn btn-outline-primary btn-lg">Save</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                    <div class="table-responsive">
                        <table class="table table-bordered table-striped">
                            <thead>
                            <tr>
                                <th>#</th>
                                <th>First name</th>
                                <th>Email</th>
                                <th>Role</th>
                                <th>Action</th>
                            </tr>
                            </thead>
                            <tbody>
                            @foreach($users as $user)
                                <tr>
                                <th scope="row">{{$i++}}</th>
                                <td>{{$user->name}}</td>
                                <td>{{$user->email}}</td>
                                <td>
                                    @foreach($user->roles as $role)
                                        <span class="tag tag-info">{{$role->name}}</span>
                                    @endforeach
                                </td>
                                <td>
                                    <div class="btn-group mr-1">
                                        <button type="button" class="btn btn-outline-primary dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">action</button>
                                        <div class="dropdown-menu">
                                            <a class="dropdown-item edit_user" href="#" data-toggle="modal" data-target="#editUser" data-id="{{$user->id}}"><i class="icon-pencil2"></i> edit </a>
                                            <a class="dropdown-item assign_role_user" href="#" data-toggle="modal" data-target="#assignRole" data-id="{{$user->id}}"><i class="icon-pencil2"></i> assign role </a>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                            @endforeach
                            </tbody>
                        </table>
                    </div>
                    <div class="card-block">
                        {{ $users->links() }}
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection