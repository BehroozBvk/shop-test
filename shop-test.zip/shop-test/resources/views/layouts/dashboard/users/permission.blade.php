@extends('layouts.dashboard.master.master')
@section('script')
    <script src="{{asset('js/axios.min.js')}}"></script>

    <script>
        $(document).ready(function(){
            $(".assign_role").click(function(e){
                e.preventDefault();
                var permission = $(this).attr('data-id');
                $('.permission').attr('value',permission);
            });

            $(".edit_permission").click(function(e){
                e.preventDefault();
                var edit_permission = $(this).attr('data-id');
                $('.edit_permission_id').attr('value',edit_permission);

                axios.post('{{route('permission.edit')}}',{
                    id:$(this).attr('data-id')
                })
                .then(function (response) {
                    $(".edit_permission_id").val(response.data.id);
                    $(".edit_name").val(response.data.name);
                    $(".edit_display_name").val(response.data.display_name);
                    $(".edit_description").val(response.data.description);
                })
                .catch(function (error) {
                    console.log(error);
                });
            });

        });
    </script>
@endsection
@section('content')
    <div class="row">
        <div class="col-xs-12">
            <div class="card">
                <div class="card-header">

                    <h4 class="card-title">Permission</h4>
                    <a class="heading-elements-toggle"><i class="icon-ellipsis font-medium-3"></i></a>
                    <div class="heading-elements">
                        <ul class="list-inline mb-0">
                            <li><a data-action="collapse"><i class="icon-minus4"></i></a></li>
                            <li><a data-action="reload"><i class="icon-reload"></i></a></li>
                            <li><a data-action="expand"><i class="icon-expand2"></i></a></li>
                            <li><a data-action="close"><i class="icon-cross2"></i></a></li>
                        </ul>
                    </div>
                    @if ($errors->any())
                        <div class="m-1">
                            <div class="alert alert-danger alert-dismissible fade in mb-2" role="alert">
                                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                    <span aria-hidden="true">×</span>
                                </button>
                                <ul>
                                    @foreach ($errors->all() as $error)
                                        <li>{{ $error }}</li>
                                    @endforeach
                                </ul>
                            </div>
                        </div>
                    @endif
                </div>
                <div class="form-group">
                    <!-- Modal -->
                    <div class="modal fade text-xs-left" id="assignPermission" tabindex="-1" role="dialog" aria-labelledby="myModalLabel33" aria-hidden="true">
                        <div class="modal-dialog" role="document">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                    <label class="modal-title text-text-bold-600" id="myModalLabel33">Assign Role</label>
                                </div>
                                <form action="{{route('permission.assign')}}" method="post">
                                    {{csrf_field()}}
                                    <div class="modal-body">
                                        <label>Role : </label>
                                        <div class="form-group">
                                            <input type="hidden" value="" class="permission" name="permission_id">
                                            <select id="role" name="role" class="form-control {{$errors->has('role') ? 'border-danger' : ''}}">
                                                <option value="" selected disabled>Select</option>
                                                @foreach($roles as $role)
                                                    <option value="{{$role->id}}">{{$role->name}}</option>
                                                @endforeach
                                            </select>
                                        </div>
                                    </div>
                                    <div class="modal-footer">
                                        <input type="reset" class="btn btn-outline-secondary btn-lg" data-dismiss="modal" value="Cancel">
                                        <button type="submit" class="btn btn-outline-primary btn-lg">Save</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                    <!-- Modal Permission Edit-->
                    <div class="modal fade text-xs-left" id="editPermission" tabindex="-1" role="dialog" aria-labelledby="myModalLabel33" aria-hidden="true">
                        <div class="modal-dialog" role="document">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                    <label class="modal-title text-text-bold-600" id="myModalLabel33">Assign Role</label>
                                </div>
                                <form action="{{route('permission.update')}}" method="post">
                                    {{csrf_field()}}
                                    <div class="modal-body">
                                        <div class="form-group">
                                            <label>Name : </label>
                                            <div class="form-group">
                                                <input type="hidden" value=""  name="edit_permission_id" class="edit_permission_id">
                                                <input name="edit_name" type="text" required value="{{ old('edit_name') }}"  placeholder="Permission Name" class="form-control edit_name">
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label>Display Name : </label>
                                            <div class="form-group">
                                                <input name="edit_display_name" type="text" required value="{{ old('edit_display_name') }}"  placeholder="Permission Name" class="form-control edit_display_name">
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label>Description : </label>
                                            <div class="form-group">
                                                <input name="edit_description" type="text" required value="{{ old('edit_description') }}"  placeholder="Description" class="form-control edit_description">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="modal-footer">
                                        <input type="reset" class="btn btn-outline-secondary btn-lg" data-dismiss="modal" value="Cancel">
                                        <button type="submit" class="btn btn-outline-primary btn-lg">Save</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="card-body collapse in">
                    <form action="{{route('permission.store')}}" method="post">
                        {{csrf_field()}}
                        <div class="col-lg-10 col-md-10 col-xs-12">
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="name">name </label>
                                    <input type="text" id="salehin_name" class="form-control {{$errors->has('name') ? 'border-danger' : ''}}" placeholder="name"
                                           name="name" value="{{old('name')}}">
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="name">display name </label>
                                    <input type="text" id="display_name" class="form-control {{$errors->has('display_name') ? 'border-danger' : ''}}" placeholder="diplay name" name="display_name" value="{{old('display_name')}}">
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <div class="form-group">
                                        <label for="description">description  </label>
                                        <input type="text" id="description " class="form-control {{$errors->has('description') ? 'border-danger' : ''}}" placeholder="description"
                                               name="description" value="{{old('description')}}">
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-2 col-md-2 col-xs-12">
                            <div class="form-group">
                                <label for="injury">&nbsp;</label>
                                <button id="save" type="submit" class="btn btn-success btn-block"><i class="icon-save"></i> save </button>
                            </div>
                        </div>
                    </form>
                    <div class="table-responsive">
                        <table class="table table-bordered table-striped">
                            <thead>
                            <tr>
                                <th>Name</th>
                                <th>Display Name</th>
                                <th>Description</th>
                                <th>Action</th>
                            </tr>
                            </thead>
                            <tbody>
                            @foreach($permissions as $permission)
                                <tr>
                                <td>{{$permission->name}}</td>
                                <td>{{$permission->display_name}}</td>
                                <td>{{$permission->description}}</td>
                                <td>
                                    <div class="btn-group mr-1">
                                        <button type="button" class="btn btn-outline-primary dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">action</button>
                                        <div class="dropdown-menu">
                                            <a class="dropdown-item assign_role" href="#" data-toggle="modal" data-target="#assignPermission" data-id="{{$permission->id}}"><i class="icon-key2"></i> Assign Permission </a>
                                            <a href="#" class="dropdown-item edit_permission" data-toggle="modal" data-target="#editPermission" data-id="{{$permission->id}}"><i class="icon-pencil2"></i> Edit Permission</a>
                                            <form action="{{route('permission.delete',$permission->id)}}" method="post">
                                                {{csrf_field()}}
                                                <button type="submit" class="dropdown-item"><i class="icon-trash2"></i> Delete Permission</button>
                                            </form>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                            @endforeach
                            </tbody>
                        </table>
                    </div>
                    <div class="card-block">
                        {{ $permissions->links() }}
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection