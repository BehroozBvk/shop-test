<!-- main menu-->
<div data-scroll-to-active="true" class="main-menu menu-fixed menu-dark menu-accordion menu-shadow">
    <!-- main menu content-->
    <div class="main-menu-content">
        <ul id="main-menu-navigation" data-menu="menu-navigation" class="navigation navigation-main">
            <li class="<?php echo e(request()->is('admin/dashboard') ? 'active' : ''); ?> nav-item"><a href="<?php echo e(route('dashboard')); ?>"><i class="icon-dashboard"></i><span data-i18n="nav.dash.main" class="menu-title">Dashboard</span></a>
            </li>

            <li class="<?php echo e(request()->is('admin/dashboard/products') ? 'active' : ''); ?> nav-item"><a href="<?php echo e(route('products')); ?>"><i class="icon-cubes"></i><span data-i18n="nav.dash.main" class="menu-title">Products</span></a>
            </li>
            <?php if (\Entrust::hasRole('admin')) : ?>
            <li class="<?php echo e(request()->is('admin/dashboard/users') ? 'open' : ''); ?> nav-item has-sub">
                <a href="<?php echo e(route('dashboard')); ?>"><i class="icon-users2"></i><span data-i18n="nav.dash.main" class="menu-title">Managments</span></a>
                <ul class="menu-content">
                    <li class="<?php echo e(request()->is('admin/dashboard/users') ? 'active' : ''); ?>"><a href="<?php echo e(route('users')); ?>" data-i18n="nav.icons.icons_feather" class="menu-item">Users</a>
                    </li>
                    <li class="<?php echo e(request()->is('admin/dashboard/users/role') ? 'active' : ''); ?>"><a href="<?php echo e(route('users.role')); ?>" data-i18n="nav.icons.icons_feather" class="menu-item">Role</a>
                    </li>
                    <li class="<?php echo e(request()->is('admin/dashboard/users/permission') ? 'active' : ''); ?>"><a href="<?php echo e(route('users.permission')); ?>" data-i18n="nav.icons.icons_feather" class="menu-item">Permission</a>
                    </li>
                </ul>
            </li>
            <?php endif; // Entrust::hasRole ?>

        </ul>
    </div>
    <!-- /main menu content-->
    <!-- main menu footer-->
    <!-- include includes/menu-footer-->
    <!-- main menu footer-->
</div>
<!-- / main menu-->