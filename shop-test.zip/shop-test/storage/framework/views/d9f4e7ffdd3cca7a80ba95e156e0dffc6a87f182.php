<?php $__env->startSection('style'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/sweetalert2.min.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script src="<?php echo e(asset('js/axios.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/sweetalert2.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/persian-date.min.js')); ?>"></script>
    <script>
        $(document).ready(function(){
            $(".edit_user").click(function(e){
                e.preventDefault();
                axios.post('<?php echo e(route('users.edit')); ?>',{
                    id:$(this).attr('data-id')
                })
                    .then(function (response) {
                        $(".edit_id").val(response.data.id);
                        $(".user-name").val(response.data.name);
                        $(".user-email").val(response.data.email);
                    })
                    .catch(function (error) {
                        console.log(error);
                    });
            });

            $(".assign_role_user").click(function(e){
                e.preventDefault();
                var user = $(this).attr('data-id');
                $('.user_id').attr('value',user);
            });
        });
        <?php if(session('success')): ?>
            swal({
                title: 'Update',
                text: '<?php echo e(session('success')); ?>',
                type: 'success',
                confirmButtonText: 'ok'
            });
        <?php endif; ?>
    </script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-xs-12">
            <div class="card">
                <div class="card-header">

                    <h4 class="card-title">Users List</h4>
                    <a class="heading-elements-toggle"><i class="icon-ellipsis font-medium-3"></i></a>
                    <div class="heading-elements">
                        <ul class="list-inline mb-0">
                            <li><a data-action="collapse"><i class="icon-minus4"></i></a></li>
                            <li><a data-action="reload"><i class="icon-reload"></i></a></li>
                            <li><a data-action="expand"><i class="icon-expand2"></i></a></li>
                            <li><a data-action="close"><i class="icon-cross2"></i></a></li>
                        </ul>
                    </div>
                    <?php if($errors->any()): ?>
                        <div class="m-1">
                            <div class="alert alert-danger alert-dismissible fade in mb-2" role="alert">
                                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                    <span aria-hidden="true">×</span>
                                </button>
                                <ul>
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>

                <div class="card-body collapse in">
                    <div class="card-block card-dashboard bs-example">
                        <!-- Modal Edit -->
                        <div class="modal fade text-xs-left" id="editUser" tabindex="-1" role="dialog" aria-labelledby="myModalLabel33" aria-hidden="true">
                            <div class="modal-dialog" role="document">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                            <span aria-hidden="true">&times;</span>
                                        </button>
                                        <label class="modal-title text-bold-600" id="myModalLabel33">Edit User</label>
                                    </div>
                                    <div class="card-block">
                                        <form class="form-horizontal form-simple" method="POST" action="<?php echo e(route('users.update')); ?>" autocomplete="none">
                                            <?php echo e(csrf_field()); ?>

                                            <input name="edit_id" type="hidden" class="edit_id">
                                            <fieldset class="form-group position-relative has-icon-left mb-1 <?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
                                                <input type="text" class="form-control form-control-lg input-lg user-name" name="name" value="<?php echo e(old('name')); ?>" required autofocus id="user-name" placeholder="First Name">
                                                <div class="form-control-position">
                                                    <i class="icon-head"></i>
                                                </div>
                                            </fieldset>
                                            <fieldset class="form-group <?php echo e($errors->has('email') ? ' has-error' : ''); ?> position-relative has-icon-left mb-1">
                                                <input type="email" class="form-control form-control-lg input-lg user-email" name="email" value="<?php echo e(old('email')); ?>" id="user-email" placeholder="Email" required>
                                                <div class="form-control-position">
                                                    <i class="icon-mail6"></i>
                                                </div>
                                            </fieldset>
                                            <fieldset class="form-group position-relative has-icon-left <?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
                                                <input type="password" class="form-control form-control-lg input-lg" name="password" id="user-password" placeholder="Password" >
                                                <div class="form-control-position">
                                                    <i class="icon-key3"></i>
                                                </div>
                                            </fieldset>
                                            <fieldset class="form-group position-relative has-icon-left <?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
                                                <input type="password" class="form-control form-control-lg input-lg" name="password_confirmation" id="password-confirm" placeholder="Confirm Password" >
                                                <div class="form-control-position">
                                                    <i class="icon-key3"></i>
                                                </div>
                                            </fieldset>
                                            <button type="submit" class="btn btn-blue btn-lg btn-block"><i class="icon-save"></i> Update</button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- Modal Assign Role -->
                        <div class="modal fade text-xs-left" id="assignRole" tabindex="-1" role="dialog" aria-labelledby="myModalLabel33" aria-hidden="true">
                            <div class="modal-dialog" role="document">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                            <span aria-hidden="true">&times;</span>
                                        </button>
                                        <label class="modal-title text-bold-600" id="myModalLabel33">Assign Role To User</label>
                                    </div>
                                    <div class="card-block">
                                        <form action="<?php echo e(route('users.assign')); ?>" method="post">
                                            <?php echo e(csrf_field()); ?>

                                            <div class="modal-body">
                                                <label>Role : </label>
                                                <div class="form-group">
                                                    <input type="hidden" value="" class="user_id" name="user_id">
                                                    <select id="role" name="role" class="form-control <?php echo e($errors->has('role') ? 'border-danger' : ''); ?>">
                                                        <option value="" selected disabled>Select</option>
                                                        <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($role->id); ?>"><?php echo e($role->name); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="modal-footer">
                                                <input type="reset" class="btn btn-outline-secondary btn-lg" data-dismiss="modal" value="Cancel">
                                                <button type="submit" class="btn btn-outline-primary btn-lg">Save</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                    <div class="table-responsive">
                        <table class="table table-bordered table-striped">
                            <thead>
                            <tr>
                                <th>#</th>
                                <th>First name</th>
                                <th>Email</th>
                                <th>Role</th>
                                <th>Action</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                <th scope="row"><?php echo e($i++); ?></th>
                                <td><?php echo e($user->name); ?></td>
                                <td><?php echo e($user->email); ?></td>
                                <td>
                                    <?php $__currentLoopData = $user->roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <span class="tag tag-info"><?php echo e($role->name); ?></span>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </td>
                                <td>
                                    <div class="btn-group mr-1">
                                        <button type="button" class="btn btn-outline-primary dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">action</button>
                                        <div class="dropdown-menu">
                                            <a class="dropdown-item edit_user" href="#" data-toggle="modal" data-target="#editUser" data-id="<?php echo e($user->id); ?>"><i class="icon-pencil2"></i> edit </a>
                                            <a class="dropdown-item assign_role_user" href="#" data-toggle="modal" data-target="#assignRole" data-id="<?php echo e($user->id); ?>"><i class="icon-pencil2"></i> assign role </a>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                    <div class="card-block">
                        <?php echo e($users->links()); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard.master.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>