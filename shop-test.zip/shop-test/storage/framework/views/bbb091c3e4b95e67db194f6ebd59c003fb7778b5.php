<?php $__env->startSection('style'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/jquery-ui.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/sweetalert2.min.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script src="<?php echo e(asset('js/jquery-ui.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/sweetalert2.min.js')); ?>"></script>

    <script type="text/javascript">
        $('.typeahead').autocomplete({
            source:'<?php echo e(route('products.autocomplete')); ?>',
            minlength:3,
            maxheight:'100px',
            autoFocus:true,
            select:function(e,ui)
            {
                var slug = function(str) {
                    var $slug = '';
                    var trimmed = $.trim(str);
                    $slug = trimmed.replace(/[^a-z0-9-]/gi, '-').
                    replace(/-+/g, '-').
                    replace(/^-|-$/g, '');
                    return $slug.toLowerCase();
                };
                window.location.href = '<?php echo e(url('/admin/dashboard/products')); ?>/'+slug(ui.item.value);
            }
        }).data( "ui-autocomplete" )._renderItem = function( ul, item ) {
            return $( "<li></li>" )
                .data( "item.autocomplete", item )
                .append( "<span class='avatar avatar-md'>" + "<img src='<?php echo e(asset('images/products')); ?>/" +((item.image == null) ? 'no-image.png' : item.image) + "' /> " + item.value+ "</span>" )
                .appendTo( ul )
        };
    </script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-xs-12">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title">Products List</h4>
                    <a class="heading-elements-toggle"><i class="icon-ellipsis font-medium-3"></i></a>
                    <div class="heading-elements">
                        <ul class="list-inline mb-0">
                            <li><a data-action="collapse"><i class="icon-minus4"></i></a></li>
                            <li><a data-action="reload"><i class="icon-reload"></i></a></li>
                            <li><a data-action="expand"><i class="icon-expand2"></i></a></li>
                            <li><a data-action="close"><i class="icon-cross2"></i></a></li>
                        </ul>
                    </div>
                </div>

                <div class="card-body collapse in">
                    <div class="card-block card-dashboard bs-example">
                        <?php if (\Entrust::hasRole('admin')) : ?>
                            <div class="col-lg-10 col-md-10 col-xs-12">
                                <input class="typeahead form-control" name="query" type="text" placeholder="Filter search by product tag ">
                            </div>
                        <?php endif; // Entrust::hasRole ?>

                        <div class="col-lg-2 col-md-2 col-xs-12">
                            <a href="<?php echo e(route('products.create')); ?>" class="btn btn-success btn-block"><i class="icon-circle-plus"></i> New</a>
                        </div>
                    </div>
                    <div class="table-responsive">
                        <table class="table table-bordered table-striped">
                            <thead>
                            <tr>
                                <th>#</th>
                                <th>Image</th>
                                <th>Product Name</th>
                                <th>Price</th>
                                <th>Tags</th>
                                <th>Date</th>
                            </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <th scope="row"><?php echo e($i++); ?></th>
                                        <td><a href="<?php echo e(route('products.show',str_slug($product->name, '-'))); ?>"><span class="avatar avatar-lg box-shadow-1"><img class="img-responsive" src="<?php echo e($product->image == NULL ? asset('images/no-image.png'):asset('images/products').'/'.$product->image); ?>"></span></a></td>
                                        <td><?php echo e($product->name); ?></td>
                                        <td>$<?php echo e($product->price); ?></td>
                                        <td>
                                            <?php $__currentLoopData = $product->tag; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div class="tag tag-pill tag-primary"><?php echo e($tag); ?></div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </td>
                                        <td><?php echo e($product->created_at); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                    <div class="card-block">
                        <?php echo e($products->links()); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard.master.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>