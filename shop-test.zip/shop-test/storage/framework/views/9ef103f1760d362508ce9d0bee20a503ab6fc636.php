<footer class="footer footer-static footer-light navbar-border">
    <p class="clearfix text-muted text-sm-center mb-0 px-2"><span class="float-md-left d-xs-block d-md-inline-block">Design By :  <a href="http://www.studio-design.ir" target="_blank" class="text-bold-800 grey darken-2">studio-design.ir </a> </span><span class="float-md-right d-xs-block d-md-inline-block">Developer : Behrooz Valikhani <i class="icon-heart5 pink"></i></span></p>
</footer>
<!-- BEGIN VENDOR JS-->
<script src="<?php echo e(asset('app-assets/js/core/libraries/jquery.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('app-assets/vendors/js/ui/tether.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('app-assets/js/core/libraries/bootstrap.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('app-assets/vendors/js/ui/perfect-scrollbar.jquery.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('app-assets/vendors/js/ui/unison.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('app-assets/vendors/js/ui/blockUI.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('app-assets/vendors/js/ui/jquery.matchHeight-min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('app-assets/vendors/js/ui/screenfull.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('app-assets/vendors/js/extensions/pace.min.js')); ?>" type="text/javascript"></script>
<!-- BEGIN VENDOR JS-->
<!-- BEGIN PAGE VENDOR JS-->
<script src="<?php echo e(asset('app-assets/vendors/js/charts/chart.min.js')); ?>" type="text/javascript"></script>
<!-- END PAGE VENDOR JS-->
<!-- BEGIN ROBUST JS-->
<script src="<?php echo e(asset('app-assets/js/core/app-menu.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('app-assets/js/core/app.js')); ?>" type="text/javascript"></script>
<!-- END ROBUST JS-->
<!-- BEGIN PAGE LEVEL JS-->

<?php echo $__env->yieldContent('script'); ?>
<!-- END PAGE LEVEL JS-->
</body>
</html>