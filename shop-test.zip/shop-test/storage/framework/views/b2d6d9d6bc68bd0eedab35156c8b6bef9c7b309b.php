<!DOCTYPE html>
<html lang="en" data-textdirection="rtl" class="loading">

<!-- Mirrored from pixinvent.com/free-bootstrap-template/robust-lite/html/rtl/error-400.html by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 22 Aug 2017 09:16:56 GMT -->
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
    <meta name="description" content="Robust admin is super flexible, powerful, clean &amp; modern responsive bootstrap 4 admin template with unlimited possibilities.">
    <meta name="keywords" content="admin template, robust admin template, dashboard template, flat admin template, responsive admin template, web app">
    <meta name="author" content="PIXINVENT">
    <title>Error 403 - Robust Free Bootstrap Admin Template</title>
    <link rel="shortcut icon" type="image/png" href="../../app-assets/images/ico/favicon-32.png">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-touch-fullscreen" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="default">
    <!-- BEGIN VENDOR CSS-->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('app-assets/css-rtl/bootstrap.css')); ?>">
    <!-- font icons-->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('app-assets/fonts/icomoon.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('app-assets/fonts/flag-icon-css/css/flag-icon.min.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('app-assets/vendors/css/extensions/pace.css')); ?>">
    <!-- END VENDOR CSS-->
    <!-- BEGIN ROBUST CSS-->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('app-assets/css-rtl/bootstrap-extended.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('app-assets/css-rtl/app.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('app-assets/css-rtl/colors.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('app-assets/css-rtl/custom-rtl.css')); ?>">
    <!-- END ROBUST CSS-->
    <!-- BEGIN Page Level CSS-->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('app-assets/css-rtl/core/menu/menu-types/vertical-menu.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('app-assets/css-rtl/core/menu/menu-types/vertical-overlay-menu.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('app-assets/css-rtl/pages/error.css')); ?>">
    <!-- END Page Level CSS-->
    <!-- BEGIN Custom CSS-->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/style-rtl.css')); ?>">
    <!-- END Custom CSS-->
</head>
<body data-open="click" data-menu="vertical-menu" data-col="1-column" class="vertical-layout vertical-menu 1-column  blank-page blank-page">
<!-- ////////////////////////////////////////////////////////////////////////////-->
<div class="app-content content container-fluid">
    <div class="content-wrapper">
        <div class="content-header row">
        </div>
        <div class="content-body"><section class="flexbox-container">
                <div class="col-md-4 offset-md-4 col-xs-10 offset-xs-1">
                    <div class="card-header bg-transparent no-border">
                        <h2 class="error-code text-xs-center mb-2"> Error 403</h2>
                        <h3 class="text-uppercase text-xs-center">Can not Access</h3>
                    </div>
                    <div class="card-body collapse in">
                        <div class="row py-2">
                            <div class="col-lg-12">
                                <a href="<?php echo e(route('dashboard')); ?>" class="btn btn-primary btn-block font-small-3"><i class="icon-home3"></i> Back to home</a>
                            </div>
                        </div>
                    </div>

                </div>
            </section>

        </div>
    </div>
</div>
<!-- ////////////////////////////////////////////////////////////////////////////-->

<!-- BEGIN VENDOR JS-->
<script src="<?php echo e(asset('app-assets/js/core/libraries/jquery.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('app-assets/vendors/js/ui/tether.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('app-assets/js/core/libraries/bootstrap.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('app-assets/vendors/js/ui/perfect-scrollbar.jquery.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('app-assets/vendors/js/ui/unison.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('app-assets/vendors/js/ui/blockUI.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('app-assets/vendors/js/ui/jquery.matchHeight-min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('app-assets/vendors/js/ui/screenfull.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('app-assets/vendors/js/extensions/pace.min.js')); ?>" type="text/javascript"></script>
<!-- BEGIN VENDOR JS-->
<!-- BEGIN PAGE VENDOR JS-->
<!-- END PAGE VENDOR JS-->
<!-- BEGIN ROBUST JS-->
<script src="<?php echo e(asset('app-assets/js/core/app-menu.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('app-assets/js/core/app.js')); ?>" type="text/javascript"></script>
<!-- END ROBUST JS-->
<!-- BEGIN PAGE LEVEL JS-->
<!-- END PAGE LEVEL JS-->
</body>

<!-- Mirrored from pixinvent.com/free-bootstrap-template/robust-lite/html/rtl/error-400.html by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 22 Aug 2017 09:16:56 GMT -->
</html>
