<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-xs-12">
            <div class="row match-height">
                <div class="col-xl-4 col-md-4 col-sm-12">
                    <img class="card-img-top img-thumbnail img-fluid centered" src="<?php echo e($product->image == NULL ? asset('images/no-image.png'):asset('images/products').'/'.$product->image); ?>" alt="<?php echo e($product->name); ?>">
                </div>
                <div class="col-xl-8 col-md-8 col-sm-12">
                    <div class="card">
                        <div class="card-body">
                            <div class="card-block">
                                <h4 class="card-title text-left-item"><?php echo e($product->name); ?></h4>
                                <p class="card-text text-left-item"><span class="text-bold-600">Content :</span> <?php echo e($product->content); ?></p>
                            </div>
                            <ul class="list-group list-group-flush">
                                <li class="list-group-item text-left-item">
                                    <i class="icon-dollar"></i> <span class="text-bold-600"> Price :</span> <?php echo e($product->price); ?>

                                </li>
                                <li class="list-group-item text-left-item">
                                    <i class="icon-tags"></i> <span class="text-bold-600">Tags :</span>
                                    <?php $__currentLoopData = $product->tag; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="tag tag-pill tag-primary"><?php echo e($tag); ?></div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </li>

                            </ul>
                        </div>
                    </div>
                    <a href="<?php echo e(route('products')); ?>" class="btn btn-danger">
                        <i class="icon-ios-undo"></i> Back
                    </a>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard.master.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>