<?php echo $__env->make('layouts.dashboard.master.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('layouts.dashboard.master.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div class="app-content content container-fluid">
    <div class="content-wrapper">
        <div class="content-header row">
        </div>
        <div class="content-body" id="bvk"><!-- stats -->
            <?php echo $__env->yieldContent('content'); ?>
        </div>
    </div>
</div>
<?php echo $__env->make('layouts.dashboard.master.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
