<?php

namespace App\Http\Controllers;

use App\Http\Requests\ProductRequest;
use App\Product;
use Illuminate\Http\Request;

class ProductController extends Controller
{
	/**
	 * @param Request $request
	 *
	 * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
	 */
	public function index(Request $request)
    {
    	$products = Product::paginate(10);
	    $i=($products->currentpage()- 1) * $products->perpage()+ 1;
        return view('layouts.dashboard.products.index',compact('products','i'));
    }

	/**
	 * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
	 */
	public function create()
    {
        return view('layouts.dashboard.products.add');
    }

	/**
	 * @param $name
	 *
	 * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
	 */
	public function show($name)
	{
		$product = Product::where('name','=',str_replace("-", " ", $name))->first();
		return view('layouts.dashboard.products.show',compact('product'));
	}

	/**
	 * @param ProductRequest $request
	 *
	 * @return \Illuminate\Http\RedirectResponse
	 */
	public function store(ProductRequest $request)
    {
        if ($request->hasFile('image')){
            $image = $request->file('image');
            $input['image'] = time().'.'.$image->getClientOriginalExtension();
            $destinationPath = public_path('/images/products');
	        $image->move($destinationPath, $input['image']);
        }else{
        	$input = null;
        }

        $save = Product::create([
            'name'=>$request->name,
            'price'=>$request->price,
            'image'=>(is_null($input) ? $input:$input['image']),
            'content'=>$request->input('content'),
            'tag'=>$request->tag,
            'user_id'=>auth()->user()->id
        ]);

        if ($save->exists){
            return redirect()->back()->with('success','The product has been successfully recorded');
        }
    }

	/**
	 * @param Request $request
	 *
	 * @return \Illuminate\Http\JsonResponse
	 */
	public function autocomplete(Request $request)
	{
		$items =Product::where('tag', 'like', '%'.$request->term.'%')
		             ->get();

		$json =array();
		foreach($items as $item){
			$json[] = ['id'=>$item->id,'value'=>$item->name,'image'=>$item->image];
		}
		return response()->json($json);
	}
}
