<?php

namespace App\Http\Controllers;

use App\Product;
use Illuminate\Http\Request;

class DashboardController extends Controller
{
    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
	    $products = Product::orderBy('id', 'desc')->take(4)->get();
        return view('layouts.dashboard.index',compact('products'));
    }
}
