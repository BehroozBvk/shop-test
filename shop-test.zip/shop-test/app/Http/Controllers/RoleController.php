<?php

namespace App\Http\Controllers;

use App\Http\Requests\RoleRequest;
use App\Role;
use Illuminate\Http\Request;

class RoleController extends Controller
{

	/**
	 * RoleController constructor.
	 */
	public function __construct() {
		$this->middleware('role:admin');
	}

	/**
	 * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
	 */
	public function index() {
		$roles = Role::paginate(10);
		return view('layouts.dashboard.users.role',compact('roles'));
    }

	/**
	 * @param RoleRequest $request
	 *
	 * @return \Illuminate\Http\RedirectResponse
	 */
	public function store(RoleRequest $request) {
		$role = new Role();
		$role->name = $request->name;
		$role->display_name = $request->display_name;
		$role->description = $request->description;
		$role->save();

		if ($role->exists){
			return redirect()->back();
		}

    }

	/**
	 * @param Request $request
	 *
	 * @return \Illuminate\Http\JsonResponse
	 */
	public function edit(Request $request)
	{
		$edit = Role::find($request->id);
		if (request()->json()){
			return response()->json($edit);
		}

	}

	/**
	 * @param Request $request
	 *
	 * @return \Illuminate\Http\RedirectResponse
	 */
	public function update(Request $request){
		$update = Role::where( 'id', $request->edit_role_id )
		                    ->update(
			                    [   'name'         => $request->edit_name,
			                        'display_name' => $request->edit_display_name,
			                        'description'  => $request->edit_description
			                    ]);
		if ($update){
			return redirect()->back();
		}
	}

	/**
	 * @param Request $request
	 *
	 * @return \Illuminate\Http\RedirectResponse
	 */
	public function delete(Request $request) {
		Role::whereId($request->id)->delete();
		return redirect()->back();
	}
}
