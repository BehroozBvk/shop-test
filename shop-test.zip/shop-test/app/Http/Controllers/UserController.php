<?php

namespace App\Http\Controllers;

use App\Role;
use App\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class UserController extends Controller
{
	/**
	 * UserController constructor.
	 */
	public function __construct() {
		$this->middleware('role:admin');
	}

	/**
	 * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
	 */
	public function index() {
		$users = User::with('roles')->paginate(10);
		$roles = Role::all();
		$i=($users->currentpage()- 1) * $users->perpage()+ 1;
		return view('layouts.dashboard.users.index',compact('users','i','roles'));
    }

	/**
	 * @param Request $request
	 *
	 * @return \Illuminate\Http\JsonResponse
	 */
	public function edit(Request $request)
	{
		$edit = User::findOrFail($request->id);

		if (request()->json()){
			return response()->json($edit);
		}
	}

	/**
	 * @param Request $request
	 *
	 * @return $this|\Illuminate\Http\RedirectResponse
	 */
	public function update(Request $request)
	{
		$validator = Validator::make($request->all(), [
			'name' => 'required|string|max:255',
			'email' => 'required|string|email|max:255|unique:users,email,'.$request->edit_id,
			'password' => 'confirmed'
		]);

		if ($validator->fails()) {
			return redirect()->back()
			                 ->withErrors($validator)
			                 ->withInput();
		}

		$user = User::find($request->edit_id);

		if (count($user)>0){
			$user->name  =$request->name ;
			$user->email =$request->email;
			if ($request->has('password'))
			{
				$user->password = bcrypt($request->password);
			}
			$update = $user->save();
		}

		if ($update){
			return redirect()->back()->with('success','User information has been updated successfully');
		}
	}

	/**
	 * @param Request $request
	 *
	 * @return \Illuminate\Http\RedirectResponse
	 */
	public function assignRole(Request $request) {
		$user = User::where('id', '=', $request->user_id)->first();
		$user->roles()->sync($request->role);
		if ($user->exists){
			return redirect()->back()->with('success','The role of the user has been successfully assigned');
		}
    }
}
