<?php

namespace App\Http\Controllers;

use App\Http\Requests\PermissionRequest;
use App\Permission;
use App\Role;
use Illuminate\Http\Request;

class PermissionController extends Controller
{
	/**
	 * PermissionController constructor.
	 */
	public function __construct() {
		$this->middleware('role:admin');
	}

	/**
	 * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
	 */
	public function index() {
		$permissions = Permission::paginate(10);
		$roles = Role::all();
		return view('layouts.dashboard.users.permission',compact('permissions','roles'));
	}

	/**
	 * @param PermissionRequest $request
	 *
	 * @return \Illuminate\Http\RedirectResponse
	 */
	public function store(PermissionRequest $request) {
		$permission = new Permission();
		$permission->name = $request->name;
		$permission->display_name = $request->display_name;
		$permission->description = $request->description;
		$permission->save();

		if ($permission->exists){
			return redirect()->back();
		}
	}

	/**
	 * @param Request $request
	 *
	 * @return \Illuminate\Http\RedirectResponse
	 */
	public function assignPermission(Request $request) {
		$role = Role::find($request->role);
		$role->attachPermission($request->permission_id);
		if ($role->exists){
			return redirect()->back();
		}
	}

	/**
	 * @param Request $request
	 *
	 * @return \Illuminate\Http\JsonResponse
	 */
	public function edit(Request $request)
	{
		$edit = Permission::find($request->id);
		if (request()->json()){
			return response()->json($edit);
		}

	}

	/**
	 * @param Request $request
	 *
	 * @return \Illuminate\Http\RedirectResponse
	 */
	public function update(Request $request){
		$update = Permission::where( 'id', $request->edit_permission_id )
		                    ->update(
		                    	[   'name'         => $request->edit_name,
	                                'display_name' => $request->edit_display_name,
	                                'description'  => $request->edit_description
			                    ]);
		if ($update){
			return redirect()->back();
		}
	}

	/**
	 * @param Request $request
	 *
	 * @return \Illuminate\Http\RedirectResponse
	 */
	public function delete(Request $request) {
		$permission = Permission::find($request->id);
		$permission->delete();
		return redirect()->back();
	}
}
