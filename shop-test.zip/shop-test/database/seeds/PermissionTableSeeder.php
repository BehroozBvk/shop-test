<?php

use Illuminate\Database\Seeder;

class PermissionTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
	    $permission = \App\Permission::insert([
		    [
			    'name' => 'product-search',
			    'display_name'=>'Prodoct Search',
			    'description'=>'Access Product Search',
			    'created_at'=>\Carbon\Carbon::now()->toDateTimeString(),
			    'updated_at'=>\Carbon\Carbon::now()->toDateTimeString(),
		    ],
		    [
			    'name' => 'product-list',
			    'display_name'=>'Product List',
			    'description'=>'Access Product List',
			    'created_at'=>\Carbon\Carbon::now()->toDateTimeString(),
			    'updated_at'=>\Carbon\Carbon::now()->toDateTimeString(),
		    ],
		    [
			    'name' => 'create-post',
			    'display_name'=>'Create Post Product',
			    'description'=>'Access Create Post Product',
			    'created_at'=>\Carbon\Carbon::now()->toDateTimeString(),
			    'updated_at'=>\Carbon\Carbon::now()->toDateTimeString(),
		    ]
	    ]);
	    $role_admin = \App\Role::find(1)->first();
	    $role_admin->perms()->sync([1,2,3]);

	    $role_seller = \App\Role::find(2)->first();
	    $role_seller->perms()->sync([2,3]);

    }
}
