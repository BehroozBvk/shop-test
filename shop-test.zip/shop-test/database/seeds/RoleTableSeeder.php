<?php

use Illuminate\Database\Seeder;

class RoleTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
	    \App\Role::insert([
		    [
			    'name' => 'admin',
			    'display_name'=>'Administrator',
			    'description'=>'Access Full Control Panel',
			    'created_at'=>\Carbon\Carbon::now()->toDateTimeString(),
			    'updated_at'=>\Carbon\Carbon::now()->toDateTimeString(),
		    ],
		    [
			    'name' => 'seller',
			    'display_name'=>'Seller',
			    'description'=>'Access To Product',
			    'created_at'=>\Carbon\Carbon::now()->toDateTimeString(),
			    'updated_at'=>\Carbon\Carbon::now()->toDateTimeString(),
		    ]
	    ]);
    }
}
