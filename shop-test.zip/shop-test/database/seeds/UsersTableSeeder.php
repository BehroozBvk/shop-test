<?php

use Illuminate\Database\Seeder;

class UsersTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
	    $faker = Faker\Factory::create();
	    $user = \App\User::create([
		    'name' => 'Iman Sedighi',
	        'email' => 'iman@theincitement.com',
	        'password' => bcrypt('123456'),
	        'remember_token' => str_random(10),
	        'api_token' => str_random(60)
	    ]);
	    $user->roles()->sync([1]);

	    foreach (range(1,50) as $index){
		    $user = \App\User::create([
			    'name' => $faker->firstName,
			    'email' => $faker->unique()->safeEmail,
			    'password' => bcrypt('secret'),
			    'remember_token' => str_random(10),
			    'api_token' => str_random(60)
		    ]);
		    $user->roles()->sync([2]);
	    }

    }
}
