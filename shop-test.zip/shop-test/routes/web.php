<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::get('/home','HomeController@index')->name('home');

Auth::routes();

Route::middleware(['validateBackHistory'])->group(function () {
	Route::prefix('admin/dashboard')->middleware('auth')->group(function () {
		Route::get('/','DashboardController@index')->name('dashboard');
		/*Products Route*/
		Route::get('products/autocomplete','ProductController@autocomplete')->name('products.autocomplete')->middleware('role:admin');
		Route::get('products','ProductController@index')->name('products');
		Route::get('products/create','ProductController@create')->name('products.create');
		Route::post('products/create','ProductController@store')->name('products.store');
		Route::get('products/{name}','ProductController@show')->name('products.show');

		/*Users Role Route*/
		Route::get('users','UserController@index')->name('users');
		Route::post('users/edit', 'UserController@edit')->name('users.edit');
		Route::post('users/update', 'UserController@update')->name('users.update');
		Route::get('users/role','RoleController@index')->name('users.role');
		Route::post('users/role','RoleController@store')->name('role.store');
		Route::post('users/role/edit','RoleController@edit')->name('role.edit');
		Route::post('users/role/update','RoleController@update')->name('role.update');
		Route::post('users/role/delete/{id}','RoleController@delete')->name('role.delete');
		Route::post('users/assign','UserController@assignRole')->name('users.assign');

		/*User Permission Route*/
		Route::get('users/permission','PermissionController@index')->name('users.permission');
		Route::post('users/permission','PermissionController@store')->name('permission.store');
		Route::post('users/permission/edit','PermissionController@edit')->name('permission.edit');
		Route::post('users/permission/update','PermissionController@update')->name('permission.update');
		Route::post('users/permission/delete/{id}','PermissionController@delete')->name('permission.delete');
		Route::post('users/permission/assign','PermissionController@assignPermission')->name('permission.assign');

	});
});